#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import subprocess
import os
import sys

# Styling colors matching the high contrast Slate 900 desk theme
BG_DARK = "#0f172a"
BG_CARD = "#1e293b"
PRIMARY_COLOR = "#3b82f6"
PRIMARY_HOVER = "#60a5fa"
TEXT_LIGHT = "#f8fafc"
TEXT_MUTED = "#94a3b8"
SUCCESS_COLOR = "#22c55e"
SUCCESS_HOVER = "#4ade80"

# Applications database
APPS = {
    "vscode": {
        "name": "Visual Studio Code",
        "description": "Full-featured code editor with debugging, git integration, and extensions.",
        "icon_char": "📝",
        "command": "wget -O /tmp/code.deb 'https://code.visualstudio.com/sha/download?build=stable&os=linux-deb-x64' && dpkg -i /tmp/code.deb || apt-get install -f -yq",
        "desktop_name": "code"
    },
    "wine": {
        "name": "Wine (Windows .exe Runner)",
        "description": "Compatibility layer. Lets you double-click and run Windows executables (.exe) inside Linux.",
        "icon_char": "🍷",
        "command": "dpkg --add-architecture i386 && apt-get update && apt-get install -yq wine wine32 wine64 libwine || apt-get install -f -yq",
        "desktop_name": "wine"
    },
    "vlc": {
        "name": "VLC Media Player",
        "description": "Powerhouse multimedia player that plays almost any video or audio format.",
        "icon_char": "🍊",
        "command": "apt-get install -yq vlc",
        "desktop_name": "vlc"
    },
    "gimp": {
        "name": "GIMP Image Editor",
        "description": "Advanced open-source image editor and design suite resembling Photoshop.",
        "icon_char": "🎨",
        "command": "apt-get install -yq gimp",
        "desktop_name": "gimp"
    },
    "libreoffice": {
        "name": "LibreOffice Suite",
        "description": "Complete word processor, presentation builder, and Excel-compatible spreadsheet editor.",
        "icon_char": "📊",
        "command": "apt-get install -yq libreoffice",
        "desktop_name": "libreoffice"
    },
    "node_git": {
        "name": "Node.js & Git DevKit",
        "description": "JavaScript runtime engine (Node v20), npm, and Git software tracker for development.",
        "icon_char": "⚙️",
        "command": "curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -yq nodejs git",
        "desktop_name": "node"
    },
    "filezilla": {
        "name": "FileZilla FTP Client",
        "description": "Polished double-pane FTP/SFTP file transfer application.",
        "icon_char": "📥",
        "command": "apt-get install -yq filezilla",
        "desktop_name": "filezilla"
    },
    "audacity": {
        "name": "Audacity Sound Lab",
        "description": "Robust audio waveform recording and sound editing studio.",
        "icon_char": "🎵",
        "command": "apt-get install -yq audacity",
        "desktop_name": "audacity"
    }
}

class AppStoreGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Cloud App Center & Installer")
        self.root.geometry("860x580")
        self.root.configure(bg=BG_DARK)
        self.current_proc = None
        self.installing = False
        self.selected_app_id = None

        self.setup_styles()
        self.build_ui()
        self.select_app("vscode")

    def setup_styles(self):
        # Configure fonts and clean widgets
        self.font_title = ("Inter", 16, "bold")
        self.font_header = ("Inter", 12, "bold")
        self.font_body = ("Inter", 10, "normal")
        self.font_mono = ("JetBrains Mono", 9, "normal")

    def build_ui(self):
        # Header banner
        header = tk.Frame(self.root, bg=BG_DARK, height=60)
        header.pack(fill=tk.X, padx=20, pady=10)
        
        title_label = tk.Label(header, text="🌟 Cloud Software Center", font=("Inter", 18, "bold"), fg=TEXT_LIGHT, bg=BG_DARK)
        title_label.pack(side=tk.LEFT)
        
        subtitle_label = tk.Label(header, text="One-click installations for Linux and Windows (.exe) desktop applications", font=self.font_body, fg=TEXT_MUTED, bg=BG_DARK)
        subtitle_label.pack(side=tk.RIGHT, pady=6)

        # Main split container
        main_pane = tk.Frame(self.root, bg=BG_DARK)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=20, pady=5)

        # Left Column: App Selector listbox
        left_frame = tk.Frame(main_pane, bg=BG_DARK, width=280)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)

        list_title = tk.Label(left_frame, text="Available Software Packages", font=self.font_header, fg=TEXT_MUTED, bg=BG_DARK, anchor="w")
        list_title.pack(fill=tk.X, pady=(0, 6))

        self.app_listbox = tk.Listbox(
            left_frame, 
            bg=BG_CARD, 
            fg=TEXT_LIGHT, 
            selectbackground=PRIMARY_COLOR, 
            selectforeground=TEXT_LIGHT,
            bd=0, 
            highlightthickness=1, 
            highlightbackground="#334155",
            font=self.font_body,
            activestyle="none"
        )
        self.app_listbox.pack(fill=tk.BOTH, expand=True)
        self.app_listbox.bind('<<ListboxSelect>>', self.on_listbox_change)
        
        # Populate Listbox names
        for app_id, data in APPS.items():
            self.app_listbox.insert(tk.END, f" {data['icon_char']}  {data['name']}")

        # Right Column: Info & Logs
        self.right_frame = tk.Frame(main_pane, bg=BG_DARK)
        self.right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Single app info details panel
        self.info_panel = tk.Frame(self.right_frame, bg=BG_CARD, bd=0, highlightthickness=1, highlightbackground="#334155", padx=16, pady=16)
        self.info_panel.pack(fill=tk.X)

        self.app_title_lbl = tk.Label(self.info_panel, text="VS Code Editor", font=self.font_title, fg=TEXT_LIGHT, bg=BG_CARD)
        self.app_title_lbl.pack(anchor="w")

        self.app_desc_lbl = tk.Label(self.info_panel, text="", font=self.font_body, fg=TEXT_MUTED, bg=BG_CARD, justify=tk.LEFT, wraplength=480)
        self.app_desc_lbl.pack(anchor="w", pady=8)

        # App Actions (Install / Cancel button)
        action_bar = tk.Frame(self.info_panel, bg=BG_CARD)
        action_bar.pack(fill=tk.X, pady=(10, 0))

        self.install_btn = tk.Button(
            action_bar, 
            text="Install Package", 
            font=self.font_header, 
            bg=PRIMARY_COLOR, 
            fg=TEXT_LIGHT, 
            activebackground=PRIMARY_HOVER, 
            activeforeground=TEXT_LIGHT,
            bd=0, 
            padx=20, 
            pady=6, 
            relief=tk.FLAT,
            command=self.start_installation
        )
        self.install_btn.pack(side=tk.LEFT)

        self.progress_bar = ttk.Progressbar(action_bar, orient=tk.HORIZONTAL, mode='indeterminate', length=200)
        
        # Status Label
        self.status_lbl = tk.Label(action_bar, text="Ready", font=self.font_body, fg=SUCCESS_COLOR, bg=BG_CARD)
        self.status_lbl.pack(side=tk.RIGHT)

        # Active installation terminal console logs
        log_frame = tk.Frame(self.right_frame, bg=BG_DARK)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(15, 0))

        log_title = tk.Label(log_frame, text="Active Installation Logs & Output", font=self.font_header, fg=TEXT_MUTED, bg=BG_DARK, anchor="w")
        log_title.pack(fill=tk.X, pady=(0, 6))

        self.log_text = tk.Text(
            log_frame, 
            bg="#020617", 
            fg="#10b981", 
            insertbackground="#10b981",
            font=self.font_mono, 
            bd=0, 
            highlightthickness=1, 
            highlightbackground="#1e293b",
            padx=10, 
            pady=10
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Insert initial help trace
        self.log_print("System ready. Select a software package and click install.\nAll commands run as root, and dependencies are resolved automatically.\n")

    def on_listbox_change(self, evt):
        selection = self.app_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        app_id = list(APPS.keys())[idx]
        self.select_app(app_id)

    def select_app(self, app_id):
        self.selected_app_id = app_id
        app_data = APPS[app_id]
        
        self.app_title_lbl.config(text=f"{app_data['icon_char']} {app_data['name']}")
        self.app_desc_lbl.config(text=app_data['description'])
        
        if self.installing:
            self.install_btn.config(state=tk.DISABLED)
        else:
            self.install_btn.config(state=tk.NORMAL)
            self.install_btn.config(text=f"Install {app_data['name']}", bg=PRIMARY_COLOR)

    def log_print(self, text):
        self.log_text.insert(tk.END, text)
        self.log_text.see(tk.END)

    def log_clear(self):
        self.log_text.delete(1.0, tk.END)

    def start_installation(self):
        if self.installing:
            return
        
        app_id = self.selected_app_id
        if not app_id:
            return

        confirm = messagebox.askyesno(
            "Confirm Installation", 
            f"Do you want to download and install {APPS[app_id]['name']} now?\nThis might take a few moments depending on internet speed."
        )
        if not confirm:
            return

        self.installing = True
        self.install_btn.config(state=tk.DISABLED)
        self.progress_bar.pack(side=tk.LEFT, padx=15)
        self.progress_bar.start(10)
        self.status_lbl.config(text="Installing...", fg="#f59e0b")
        self.log_clear()
        
        # Spawn asynchronous thread to avoid freezing GUI
        thread = threading.Thread(target=self.run_install_thread, args=(app_id,))
        thread.daemon = True
        thread.start()

    def run_install_thread(self, app_id):
        app_data = APPS[app_id]
        self.log_print(f">>> Starting setup process for {app_data['name']}...\n")
        self.log_print(f">>> Standard apt locks will be unlocked.\n")
        
        # Ensure we unlock standard apt lock leftovers
        unlock_cmd = "rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock"
        subprocess.run(unlock_cmd, shell=True)
        
        # Execute the script command streaming output
        cmd = f"export DEBIAN_FRONTEND=noninteractive && {app_data['command']}"
        self.current_proc = subprocess.Popen(
            cmd, 
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        while True:
            line = self.current_proc.stdout.readline()
            if not line:
                break
            self.log_print(line)
        
        rc = self.current_proc.wait()
        
        # Completed
        self.root.after(0, lambda: self.finish_installation(rc, app_data))

    def finish_installation(self, return_code, app_data):
        self.installing = False
        self.progress_bar.stop()
        self.progress_bar.pack_forget()
        self.install_btn.config(state=tk.NORMAL)
        
        if return_code == 0:
            self.status_lbl.config(text="Installed Successfully! 🎉", fg=SUCCESS_COLOR)
            self.log_print(f"\n⚡ SUCCESS: {app_data['name']} was installed successfully.\n")
            
            # Automatically find and copy installed .desktop shortcut to /root/Desktop
            desktop_dir = '/root/Desktop'
            search_dirs = ['/usr/share/applications', '/usr/local/share/applications']
            target_name = app_data.get("desktop_name", "").lower()
            copied_shortcuts = []
            
            if not os.path.exists(desktop_dir):
                os.makedirs(desktop_dir, exist_ok=True)
                
            for s_dir in search_dirs:
                if os.path.exists(s_dir):
                    for fname in os.listdir(s_dir):
                        if fname.endswith('.desktop') and (target_name in fname.lower()):
                            src_path = os.path.join(s_dir, fname)
                            dst_path = os.path.join(desktop_dir, fname)
                            try:
                                import shutil
                                shutil.copy2(src_path, dst_path)
                                os.chmod(dst_path, 0o755)
                                copied_shortcuts.append(fname)
                            except Exception as e:
                                self.log_print(f"Warning copying shortcut: {str(e)}\n")
            
            if copied_shortcuts:
                self.log_print(f"Copied desktop launchers: {', '.join(copied_shortcuts)}\n")
            else:
                self.log_print("Note: App installed. Standard system launchers are accessible or will appear on next reboot!\n")
                
            self.log_print("Desktop environment notifications triggered.\n")
            # Trigger pcmanfm desktop refresh
            subprocess.run("pcmanfm --reconnect || true", shell=True)
            
            messagebox.showinfo("Success", f"{app_data['name']} has been installed successfully!")
        else:
            self.status_lbl.config(text="Installation Failed ⚠️", fg="#ef4444")
            self.log_print(f"\n❌ ERROR: Installation exited with code {return_code}.\n")
            messagebox.showerror("Error", f"Failed to install {app_data['name']}. Please consult the logs.")

if __name__ == "__main__":
    if os.getuid() != 0:
        print("Please run as root / sudo to allow installation privileges.")
        sys.exit(1)
        
    root = tk.Tk()
    app = AppStoreGUI(root)
    root.mainloop()
