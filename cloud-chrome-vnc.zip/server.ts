import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import net from 'net';
import { spawn, exec, execSync } from 'child_process';
import path from 'path';
import fs from 'fs';
import puppeteer from 'puppeteer';

// Global flag to coordinate desktop session restarts and prevent rapid auto-respawning of daemon processes
let shutdownActive = false;

// Server application with Vite and VNC WS bridge
async function startServer() {
  const app = express();
  const server = createServer(app);
  const PORT = 3000;

  console.log('1. Setting up VNC WebSocket Bridge (/vnc)...');
  const wss = new WebSocketServer({ 
    server, 
    path: '/vnc',
    handleProtocols: (protocols) => {
      // noVNC requires the server to echo back the requested subprotocol (e.g. 'binary')
      return protocols.has('binary') ? 'binary' : (protocols.size > 0 ? protocols.values().next().value : false);
    }
  });

  wss.on('error', (err) => {
    console.error('[WS] WebSocket Server error:', err);
  });

  wss.on('connection', (ws) => {
    console.log('[WS] Client connected to VNC WebSocket');
    
    // Set up a keep-alive ping interval to prevent Cloud Run from dropping idle connections
    const pingInterval = setInterval(() => {
      if (ws.readyState === ws.OPEN) {
        ws.ping();
      }
    }, 15000);

    // Connect to local x11vnc server (port 5900)
    const vncSocket = net.connect({ host: '127.0.0.1', port: 5900 }, () => {
      console.log('[TCP] Connected to local x11vnc server');
      vncSocket.setNoDelay(true); // Disable TCP delay/Nagle's algorithm for instant input rendering
    });

    ws.on('error', (err) => {
      console.error('[WS] WebSocket error:', err.message);
    });

    ws.on('message', (data) => {
      // FIX [ERR_INVALID_ARG_TYPE]: Wrap ArrayBuffer from WS inside Node.js Buffer
      let buffer: Buffer;
      if (Buffer.isBuffer(data)) {
        buffer = data;
      } else if (data instanceof ArrayBuffer) {
        buffer = Buffer.from(data);
      } else {
        buffer = Buffer.from(data as any);
      }

      if (!vncSocket.destroyed) {
        vncSocket.write(buffer);
      }
    });

    vncSocket.on('data', (data) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(data);
      }
    });

    vncSocket.on('error', (err) => {
      console.error('[TCP] VNC Socket error:', err.message);
    });

    ws.on('close', () => {
      console.log('[WS] WebSocket closed by client');
      clearInterval(pingInterval);
      vncSocket.destroy();
    });

    vncSocket.on('close', () => {
      console.log('[TCP] VNC connection closed by backend');
      clearInterval(pingInterval);
      if (ws.readyState === ws.OPEN) {
        ws.close();
      }
    });
  });

  // ========== REAL-TIME DESKTOP AUDIO STREAMING ==========
  app.get('/api/audio', (req, res) => {
    // Write headers for continuous chunked MP3 streaming
    res.writeHead(200, {
      'Content-Type': 'audio/mpeg',
      'Connection': 'keep-alive',
      'Transfer-Encoding': 'chunked',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });

    console.log('[Audio API] High fluid client connected, streaming desktop audio...');

    // Transcode audio feed from PulseAudio default loop to compact MP3
    const ffmpegProc = spawn('ffmpeg', [
      '-f', 'pulse',
      '-i', 'default',
      '-acodec', 'libmp3lame',
      '-b:a', '128k',
      '-f', 'mp3',
      'pipe:1'
    ]);

    ffmpegProc.stdout.on('data', (chunk) => {
      res.write(chunk);
    });

    req.on('close', () => {
      console.log('[Audio API] Client disconnected, killing ffmpeg encoder');
      ffmpegProc.kill('SIGKILL');
    });

    ffmpegProc.on('close', () => {
      res.end();
    });

    ffmpegProc.on('error', (err) => {
      console.error('[Audio API] ffmpeg error:', err.message);
      res.end();
    });
  });

  // ========== DESKTOP SESSION HOT RESTART ==========
  app.post('/api/restart-desktop', (req, res) => {
    console.log('[Restart API] Executing high-speed desktop session soft refresh...');
    bootVNCService();
    res.json({ status: 'restarting' });
  });

  console.log('2. Mounting Vite Middleware...');
  const isProd = process.env.NODE_ENV === 'production' || 
                 (typeof __filename !== 'undefined' && __filename.endsWith('server.cjs')) ||
                 !fs.existsSync(path.join(process.cwd(), 'server.ts'));

  if (!isProd) {
    console.log('[Mode] Starting in DEVELOPMENT mode with Vite middleware...');
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log('[Mode] Starting in PRODUCTION mode with static file serving...');
    let distPath = path.join(process.cwd(), 'dist');
    if (typeof __dirname !== 'undefined') {
      if (fs.existsSync(path.join(__dirname, 'index.html'))) {
        distPath = __dirname;
      } else if (fs.existsSync(path.join(__dirname, 'dist', 'index.html'))) {
        distPath = path.join(__dirname, 'dist');
      }
    }
    console.log(`[Mode] Production static files path: ${distPath}`);
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.on('error', (e: any) => {
    if (e.code === 'EADDRINUSE') {
      console.log('Address in use, retrying...');
      setTimeout(() => {
        server.close();
        server.listen(PORT, '0.0.0.0');
      }, 1000);
    } else {
      console.error('Server error:', e);
    }
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    bootVNCService();
  });
}

function bootVNCService() {
  console.log('3. Booting up System Dependencies...');
  shutdownActive = true;
  
  exec('killall -9 Xvfb x11vnc fluxbox chrome pcmanfm tint2 pulseaudio ffmpeg || true', () => {
    shutdownActive = false;
    console.log('Orphaned processes cleaned. Checking if x11vnc is already installed...');
    
    exec('which x11vnc', (err) => {
      if (!err) {
        console.log('x11vnc is already installed! Booting up Linux Desktop environment instantly...');
        exec('pulseaudio -D --exit-idle-time=-1 --disallow-exit --allow-root-uid=yes --log-target=syslog || true', () => {
          startLinuxDesktop();
        });
        return;
      }
      
      console.log('x11vnc not found. Preparing full apt installation...');
      const aptCommand = 'export DEBIAN_FRONTEND=noninteractive && rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock && apt-get update && apt-get install -yq -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" xvfb pcmanfm tint2 wget x11vnc fluxbox dbus-x11 xterm htop lxtask mousepad python3-tk gdebi fonts-noto-core fonts-noto-ui-core fonts-noto-mono fonts-liberation fonts-dejavu-core pulseaudio ffmpeg librsvg2-common gnome-icon-theme adwaita-icon-theme || true';
      exec(aptCommand, (error, stdout, stderr) => {
        console.log('Apt dependencies setup completed.');
        
        console.log('Regenerating gdk-pixbuf loaders and font-caches for crisp SVG rendering...');
        exec('gdk-pixbuf-query-loaders --update-cache || true', () => {
          exec('fc-cache -fv || true', () => {
            console.log('Booting PulseAudio as system-wide / root background service...');
            exec('pulseaudio -D --exit-idle-time=-1 --disallow-exit --allow-root-uid=yes --log-target=syslog || true', () => {
              console.log('PulseAudio started. Booting up Linux Desktop environment...');
              startLinuxDesktop();
            });
          });
        });
      });
    });
  });
}

function safeSpawn(name: string, args: string[], options: any = {}, logStdout = false, logStderr = true) {
  if (shutdownActive) {
    console.log(`[Spawn] Shutdown active. Suppressing spawn of ${name}`);
    return null;
  }
  const proc = spawn(name, args, options);
  console.log(`[Spawn] Started ${name} (PID: ${proc.pid}) with arguments: ${args.join(' ')}`);

  if (logStdout && proc.stdout) {
    proc.stdout.on('data', (d) => console.log(`[${name} output]`, d.toString().trim()));
  }

  if (logStderr && proc.stderr) {
    proc.stderr.on('data', (d) => console.error(`[${name} error]`, d.toString().trim()));
  }

  proc.on('exit', (code, signal) => {
    if (shutdownActive) {
      console.log(`[Spawn] ${name} exited during shutdown. Not respawning.`);
      return;
    }
    console.warn(`[Spawn] ${name} exited with code ${code} / signal ${signal}. Respawning in 2s...`);
    setTimeout(() => {
      safeSpawn(name, args, options, logStdout, logStderr);
    }, 2000);
  });

  proc.on('error', (err) => {
    console.error(`[Spawn] ${name} error:`, err.message);
  });

  return proc;
}

function startLinuxDesktop() {
  console.log('Starting Xvfb on :99 (1920x1080)...');
  const xvfb = safeSpawn('Xvfb', [':99', '-screen', '0', '1920x1080x24'], {}, false, true);
  
  setTimeout(() => {
    console.log('Starting Fluxbox window manager...');
    const fluxbox = safeSpawn('fluxbox', [], { env: { ...process.env, DISPLAY: ':99' } }, false, true);

    console.log('Starting x11vnc with low-latency polling...');
    const x11vnc = safeSpawn('x11vnc', [
      '-display', ':99', 
      '-nopw', 
      '-listen', '127.0.0.1', 
      '-xkb', 
      '-forever', 
      '-shared', 
      '-noscr',
      '-wait', '10',  // Accelerates screen state scan loops (10ms polling)
      '-defer', '5'   // Keeps client presentation delay to a bare minimum (5ms updates)
    ], {}, true, true);

    setTimeout(async () => {
      console.log('Setting up desktop environment...');
      try {
        const chromePath = await puppeteer.executablePath();
        console.log(`Using Chromium at ${chromePath}`);

        // Symlink OS /root directories to our persistent project workspace directory
        const persistentBase = path.join(process.cwd(), 'root');
        if (!fs.existsSync(persistentBase)) {
          fs.mkdirSync(persistentBase, { recursive: true });
        }

        const foldersToPersist = ['Desktop', 'Downloads', '.chrome-user-data', '.config'];
        foldersToPersist.forEach(f => {
          const workspacePath = path.join(persistentBase, f);
          const systemPath = path.join('/root', f);

          if (!fs.existsSync(workspacePath)) {
            fs.mkdirSync(workspacePath, { recursive: true });
          }

          try {
            // Remove existing system folder/symlink and link it to our workspace
            execSync(`rm -rf "${systemPath}" && ln -sf "${workspacePath}" "${systemPath}"`);
            console.log(`Persistence Link Created: ${systemPath} -> ${workspacePath}`);
          } catch (symErr: any) {
            console.error(`Failed to link ${systemPath} to workspace:`, symErr.message);
          }
        });

        // Setup desktop files and start pcmanfm independently
        const setupDesktop = () => {
          const desktopDir = '/root/Desktop';
          if (!fs.existsSync(desktopDir)) fs.mkdirSync(desktopDir, { recursive: true });

          // Setup fontconfig to ensure all fonts render perfectly sharp with anti-aliasing
          const fontconfigDir = '/root/.config/fontconfig';
          if (!fs.existsSync(fontconfigDir)) fs.mkdirSync(fontconfigDir, { recursive: true });
          fs.writeFileSync(path.join(fontconfigDir, 'fonts.conf'), `<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">
<fontconfig>
  <match target="font">
    <edit name="antialias" mode="assign">
      <bool>true</bool>
    </edit>
    <edit name="hinting" mode="assign">
      <bool>true</bool>
    </edit>
    <edit name="hintstyle" mode="assign">
      <const>hintslight</const>
    </edit>
    <edit name="rgba" mode="assign">
      <const>rgb</const>
    </edit>
    <edit name="lcdfilter" mode="assign">
      <const>lcddefault</const>
    </edit>
  </match>
</fontconfig>`);

          // Point to persistent user data directory so cookies and logins are preserved!
          const persistentChromeDataDir = '/root/.chrome-user-data';
          if (!fs.existsSync(persistentChromeDataDir)) {
            fs.mkdirSync(persistentChromeDataDir, { recursive: true });
          }
          
          // Enhanced fluidity flags for Chrome: Use GPU-oriented SW rasterizer (SwiftShader) and disable strict bottlenecks
          const chromeFlags = [
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--ignore-gpu-blocklist',
            '--enable-gpu-rasterization',
            '--enable-oop-rasterization',
            '--enable-zero-copy',
            '--num-raster-threads=4',
            '--canvas-oop-rasterization',
            '--autoplay-policy=no-user-gesture-required',
            '--window-position=0,0',
            '--window-size=1920,1080',
            '--start-maximized',
            `--user-data-dir=${persistentChromeDataDir}`,
            '--no-first-run',
            '--password-store=basic', // Avoid gnome-keyring / system auth prompt lockouts
            '--use-mock-keychain'      // Secure mock credentials keychain for seamless session cookie writing
          ].join(' ');

          // Create a custom robust Chrome Launcher that removes SingletonLocks on every boot to guarantee persistent login state
          const chromeLauncherPath = '/root/chrome-launcher.sh';
          fs.writeFileSync(chromeLauncherPath, `#!/bin/bash
# Remove Chrome profile lock files which cause profile reset and block login session persistence
rm -f "${persistentChromeDataDir}/SingletonLock"
rm -f "${persistentChromeDataDir}/SingletonSocket"
rm -f "${persistentChromeDataDir}/SingletonCookie"
rm -f "${persistentChromeDataDir}/Default/SingletonLock"
rm -f "${persistentChromeDataDir}/Default/SingletonSocket"
rm -f "${persistentChromeDataDir}/Default/SingletonCookie"

# Execute Chromium with optimized flags and pass any extra arguments (like URLs)
exec "${chromePath}" ${chromeFlags} "$@"
`);
          fs.chmodSync(chromeLauncherPath, '755');

          // Clean older default desktop files to ensure a sleek, minimalist desk
          try {
            if (fs.existsSync(desktopDir)) {
              const oldFiles = fs.readdirSync(desktopDir);
              for (const file of oldFiles) {
                fs.unlinkSync(path.join(desktopDir, file));
              }
              console.log('Cleared default desktop icons successfully.');
            }
          } catch (clearErr: any) {
            console.warn('Error cleaning old desktop environment icons:', clearErr.message);
          }

          // Generate requested clean launchers and App shortcuts in standalone window mode (--app)
          
          // 1. Google Chrome Launcher
          fs.writeFileSync(path.join(desktopDir, 'Google Chrome.desktop'), `[Desktop Entry]
Version=1.0
Name=Google Chrome
Comment=Access the internet safely
Exec=${chromeLauncherPath}
Icon=/root/chrome-icon.svg
Terminal=false
Type=Application
Categories=Network;WebBrowser;`);

          // 2. YouTube Standalone App
          fs.writeFileSync(path.join(desktopDir, 'YouTube.desktop'), `[Desktop Entry]
Version=1.0
Name=YouTube App
Comment=Watch videos on YouTube in standalone app mode
Exec=${chromeLauncherPath} --app=https://www.youtube.com/
Icon=/root/youtube-icon.svg
Terminal=false
Type=Application
Categories=Network;WebBrowser;`);

          // 3. Roblox Standalone App
          fs.writeFileSync(path.join(desktopDir, 'Roblox.desktop'), `[Desktop Entry]
Version=1.0
Name=Roblox App
Comment=Play Roblox directly in standalone app mode
Exec=${chromeLauncherPath} --app=https://www.roblox.com/discover
Icon=/root/roblox-icon.svg
Terminal=false
Type=Application
Categories=Network;WebBrowser;`);

          // 4. WhatsApp Web App
          fs.writeFileSync(path.join(desktopDir, 'WhatsApp Web.desktop'), `[Desktop Entry]
Version=1.0
Name=WhatsApp Web
Comment=Message on WhatsApp in standalone app mode
Exec=${chromeLauncherPath} --app=https://web.whatsapp.com/
Icon=/root/whatsapp-icon.svg
Terminal=false
Type=Application
Categories=Network;WebBrowser;`);

          // 5. Discord Standalone App
          fs.writeFileSync(path.join(desktopDir, 'Discord.desktop'), `[Desktop Entry]
Version=1.0
Name=Discord App
Comment=Chat on Discord in standalone app mode
Exec=${chromeLauncherPath} --app=https://discord.com/app
Icon=/root/discord-icon.svg
Terminal=false
Type=Application
Categories=Network;WebBrowser;`);

          // Make the loaders fully executable so they are double-clickable and trusted in pcmanfm
          try {
            const files = fs.readdirSync(desktopDir);
            for (const file of files) {
              if (file.endsWith('.desktop')) {
                fs.chmodSync(path.join(desktopDir, file), '755');
              }
            }
            console.log('Desktop shortcut permissions updated.');
          } catch(err: any) {
            console.warn('Failed to chmod desktop shortcuts:', err.message);
          }
          
          console.log('Starting pcmanfm desktop & tint2...');
          const pcmanfm = safeSpawn('pcmanfm', ['--desktop'], { env: { ...process.env, DISPLAY: ':99' } }, false, true);
          const tint2 = safeSpawn('tint2', [], { env: { ...process.env, DISPLAY: ':99' } }, false, true);
        };

        // Download resources in background, but don't block desktop setup
        const downloadResources = () => {
          console.log('Downloading custom VNC Desktop resources (icons, wallpapers)...');
          
          // Chrome Icon
          exec('wget -qO /root/chrome-icon.svg "https://upload.wikimedia.org/wikipedia/commons/e/e1/Google_Chrome_icon_%28February_2022%29.svg"', () => {
            console.log('Chrome icon downloaded.');
          });

          // Terminal Icon
          exec('wget -qO /root/terminal-icon.svg "https://upload.wikimedia.org/wikipedia/commons/4/4f/Terminal-icon-classic.svg"', () => {
            console.log('Terminal icon downloaded.');
          });

          // Folder Icon
          exec('wget -qO /root/folder-icon.svg "https://upload.wikimedia.org/wikipedia/commons/e/ea/Gnome-folder.svg"', () => {
            console.log('Folder icon downloaded.');
          });

          // Text Editor Icon
          exec('wget -qO /root/text-editor-icon.svg "https://upload.wikimedia.org/wikipedia/commons/0/03/Gnome-document-new.svg"', () => {
             console.log('Text editor icon downloaded.');
          });

          // Task Manager Icon
          exec('wget -qO /root/task-manager-icon.svg "https://upload.wikimedia.org/wikipedia/commons/6/62/System_monitor_icon.svg"', () => {
             console.log('Task manager icon downloaded.');
          });

          // System Monitor Icon
          exec('wget -qO /root/sys-monitor-icon.svg "https://upload.wikimedia.org/wikipedia/commons/9/90/Gnome-utilities-system-monitor.svg"', () => {
             console.log('System monitor icon downloaded.');
          });

           // YouTube Icon
          exec('wget -qO /root/youtube-icon.svg "https://upload.wikimedia.org/wikipedia/commons/4/42/YouTube_icon_%282013-2017%29.svg"', () => {
             console.log('YouTube icon downloaded.');
          });
 
          // Roblox Icon
          exec('wget -qO /root/roblox-icon.svg "https://upload.wikimedia.org/wikipedia/commons/e/ea/Roblox_Logo_2022.svg"', () => {
             console.log('Roblox icon downloaded.');
          });
 
          // WhatsApp Icon
          exec('wget -qO /root/whatsapp-icon.svg "https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"', () => {
             console.log('WhatsApp icon downloaded.');
          });
 
          // Discord Icon
          exec('wget -qO /root/discord-icon.svg "https://upload.wikimedia.org/wikipedia/commons/e/ee/Discord_Color_Logo.svg"', () => {
             console.log('Discord icon downloaded.');
          });
 
          // Stunning dark liquid gold/glass high-res abstract wallpaper for a premium vibe 
          const wallpaperUrl = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1920&auto=format&fit=crop';
          exec(`wget -qO /root/wallpaper.jpg "${wallpaperUrl}"`, () => {
            console.log('Premium liquid glass wallpaper downloaded successfully.');
            // Give pcmanfm 3 seconds to fully boot and register the window, then set wallpaper
            setTimeout(() => {
              exec('pcmanfm --set-wallpaper /root/wallpaper.jpg --wallpaper-mode=crop', { env: { ...process.env, DISPLAY: ':99' } }, (err) => {
                if (err) console.warn('Failed to apply wallpaper via pcmanfm:', err.message);
                else console.log('Wallpaper set successfully!');
              });
            }, 3000);
          });
        };
        
        setupDesktop();
        downloadResources();

      } catch (e) {
        console.error('Desktop setup failed:', e);
      }
    }, 2000); // Give Xvfb and VNC 2 seconds to initialize
  }, 1000); // Wait 1 second for Xvfb to be ready
}

startServer().catch(console.error);
