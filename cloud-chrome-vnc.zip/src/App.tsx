import { useEffect, useRef, useState } from 'react';
// @ts-ignore
import RFB from '@novnc/novnc';
import { 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  DownloadCloud, 
  Info, 
  Monitor, 
  Sparkles,
  HelpCircle,
  Maximize2,
  Minimize2,
  Maximize,
  Minimize,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const [status, setStatus] = useState('Initializing VNC connection...');
  const [isConnected, setIsConnected] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true); // Smooth disconnect overlay to prevent flickering
  const [isMuted, setIsMuted] = useState(false); // Enable audio stream to be active automatically
  const [isRestarting, setIsRestarting] = useState(false);
  const [showInfo, setShowInfo] = useState(false); // Default hidden for a perfectly clean slate desktop on load
  const [audioUrl, setAudioUrl] = useState('');
  const [scaleViewport, setScaleViewport] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [controlsCollapsed, setControlsCollapsed] = useState(false);

  const rfbRef = useRef<any>(null);

  // Debounced overlay trigger to absorb transient disconnections and prevent rapid flashing
  useEffect(() => {
    if (isConnected) {
      setShowOverlay(false);
    } else {
      const timer = setTimeout(() => {
        setShowOverlay(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [isConnected]);

  // Sync state with standard browser HTM5 fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Failed to enter fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen().catch((err) => {
        console.error(`Failed to exit fullscreen: ${err.message}`);
      });
    }
  };

  // Synchronously update RFB viewport scaling model
  useEffect(() => {
    if (rfbRef.current) {
      rfbRef.current.scaleViewport = scaleViewport;
      try {
        // Trigger RFB standard component resize calculation to reassert dimensions
        rfbRef.current._updateScaledDims();
      } catch (e) {}
    }
  }, [scaleViewport]);

  // Manage VNC connection
  useEffect(() => {
    if (!containerRef.current) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/vnc`;

    let rfb: any = null;
    let retryTimeout: NodeJS.Timeout;

    const connectVNC = () => {
      console.log(`Connecting to ${wsUrl}...`);
      setStatus('Connecting to remote stream...');
      setIsConnected(false);

      if (containerRef.current) {
        containerRef.current.innerHTML = ''; // Clean old canvases
      }

      try {
        rfb = new RFB(containerRef.current, wsUrl, {
          credentials: { password: '' }
        });

        rfbRef.current = rfb;

        rfb.addEventListener('connect', () => {
          console.log('RFB Connected!');
          setStatus('Desktop live stream initialized');
          setIsConnected(true);
        });

        rfb.addEventListener('disconnect', (e: any) => {
          console.log('RFB Disconnected', e.detail);
          setStatus('Connection lost. Retrying in 1.5s...');
          setIsConnected(false);
          rfbRef.current = null;
          retryTimeout = setTimeout(connectVNC, 1500);
        });

        rfb.scaleViewport = scaleViewport;
        rfb.resizeSession = true;
        rfb.showDotCursor = true;
        rfb.focusOnClick = true; // Fix focus immediately so keys work seamlessly!
        
        // Premium high definition quality settings for VNC rendering
        rfb.qualityLevel = 9;       // Maximum sharpness (0-9 range)
        rfb.compressionLevel = 1;   // Minimal compression artifacts (0-9 range)
        
      } catch (e: any) {
        console.error('Error starting RFB:', e);
        setStatus(`Initialization error: ${e.message}`);
        setIsConnected(false);
        retryTimeout = setTimeout(connectVNC, 1500);
      }
    };

    connectVNC();

    return () => {
      clearTimeout(retryTimeout);
      if (rfb) {
        rfb.disconnect();
      }
      rfbRef.current = null;
    };
  }, []);

  // Sync audio stream source based on mute state to keep stream fully live with zero buffer drift
  useEffect(() => {
    if (!isMuted) {
      // Point audio to streaming endpoint with dynamic time feed to ignore old browser playback cache
      setAudioUrl(`/api/audio?t=${Date.now()}`);
    } else {
      setAudioUrl('');
    }
  }, [isMuted]);

  useEffect(() => {
    if (audioRef.current) {
      if (!isMuted && audioUrl) {
        audioRef.current.load();
        audioRef.current.play().catch(e => {
          console.warn("Audio autoplay blocked by browser sandbox. Interaction required.", e);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [audioUrl, isMuted]);

  // Audio Autoplay bypass for strict sandboxed frames: Auto unlock on first user gesture anywhere
  useEffect(() => {
    const unlockAudio = () => {
      if (audioRef.current && !isMuted) {
        audioRef.current.play()
          .then(() => {
            console.log("Audio pipeline successfully unlocked through user interaction.");
            cleanup();
          })
          .catch((err) => {
            console.warn("Retrying fluid audio unlock on next interaction...", err);
          });
      }
    };

    const cleanup = () => {
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
      window.removeEventListener('mousedown', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };

    window.addEventListener('click', unlockAudio);
    window.addEventListener('keydown', unlockAudio);
    window.addEventListener('mousedown', unlockAudio);
    window.addEventListener('touchstart', unlockAudio);

    return cleanup;
  }, [isMuted, audioUrl]);

  // Request high-speed session soft restart
  const handleRestartDesktop = async () => {
    if (isRestarting) return;
    const confirm = window.confirm("Do you want to refresh the desktop session? This will kill stuck apps and clear memory without closing this tab.");
    if (!confirm) return;

    setIsRestarting(true);
    setStatus("Restarting GUI processes...");
    try {
      const resp = await fetch('/api/restart-desktop', { method: 'POST' });
      const data = await resp.json();
      console.log("Desktop restarting response status:", data);
      
      // Delay to let system boot dependencies smoothly
      setTimeout(() => {
        setIsRestarting(false);
        setStatus("Desktop restarted. Syncing canvas...");
        window.location.reload(); // Quick browser reload to binds VNC client cleanly
      }, 5000);
    } catch(err) {
      console.error("Failed to restart desktop session:", err);
      setIsRestarting(false);
      setStatus("Failed to soft-reboot. Retrying...");
    }
  };

  return (
    <div className="w-full h-screen bg-[#090d16] flex flex-col font-sans text-slate-100 relative overflow-hidden select-none">
      
      {/* Background Audio Node */}
      {audioUrl && (
        <audio 
          ref={audioRef} 
          src={audioUrl} 
          autoPlay 
          controls={false} 
          style={{ display: 'none' }} 
        />
      )}

      {/* Primary Virtual Desktop Frame viewport container (covers 100% full screen) */}
      <main className={`relative w-full h-full flex-1 flex items-center justify-center cursor-default bg-[#05070a] ${scaleViewport ? 'overflow-hidden' : 'overflow-auto'}`}>
        <div 
          ref={containerRef} 
          className={`w-full h-full absolute inset-0 noVNC-canvas-container ${scaleViewport ? 'scale-fit' : 'scale-native'}`}
        />

        {/* Absolute Loading / Syncing / Disconnect Glass Overlay */}
        {!isConnected && showOverlay && (
          <div className="absolute inset-0 bg-[#05070a]/60 backdrop-blur-md z-20 flex flex-col items-center justify-center p-4 transition-all duration-500">
            <div className="flex flex-col items-center gap-5 p-8 rounded-2xl bg-[#0f172a]/90 border border-white/10 shadow-[0_12px_45px_rgba(0,0,0,0.85)] max-w-sm w-full text-center relative overflow-hidden">
              {/* Spinning Loader Ring with cyan light */}
              <div className="relative flex items-center justify-center w-14 h-14">
                <div className="absolute w-10 h-10 rounded-full border-4 border-slate-700/50" />
                <div className="absolute w-10 h-10 rounded-full border-4 border-t-sky-400 border-r-transparent border-b-transparent border-l-transparent animate-spin" />
                <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
              </div>

              <div className="space-y-1.5 relative">
                <h3 className="font-semibold text-sm tracking-wide text-slate-100">Syncing Workspace Stream</h3>
                <p className="text-xs text-sky-300/80 leading-relaxed font-mono px-2 select-none">
                  {status || 'Establishing connection...'}
                </p>
              </div>

              <div className="pt-2 text-[9px] text-slate-500 font-mono tracking-wider select-none uppercase">
                Offline-Safe Session Persistence Active
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Floating Liquid Glass Control Dock */}
      <div className="fixed top-4 right-4 z-30 transition-all duration-300">
        {controlsCollapsed ? (
          /* Sleek pulsing glass circle button used to restore the dock */
          <button
            type="button"
            onClick={() => setControlsCollapsed(false)}
            className="group flex h-10 w-10 items-center justify-center rounded-xl bg-slate-950/65 backdrop-blur-xl border border-white/10 text-slate-300 hover:text-white hover:bg-slate-900/85 hover:border-white/20 transition-all duration-300 shadow-2xl cursor-pointer relative"
            title="Show Controls Panel"
          >
            <ChevronLeft className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
            <span className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full ${isConnected ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-amber-500 shadow-[0_0_10px_#f59e0b] animate-pulse'}`} />
          </button>
        ) : (
          /* Full Liquid Glass Floating Panel */
          <div className="flex items-center gap-2.5 p-2 px-3 rounded-2xl bg-[#0b0f19]/75 backdrop-blur-xl border border-white/10 shadow-[0_12px_40px_rgba(0,0,0,0.65)] hover:border-white/15 transition-all duration-300 max-w-sm md:max-w-2xl flex-nowrap">
            
            {/* Branded Watermark Badge: "Made by Manue23aa" in rich shiny metallic liquid glass font */}
            <div className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-sky-500/10 via-indigo-500/10 to-purple-500/10 border border-white/5 shadow-inner rounded-xl animate-fade-in">
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-mono font-medium select-none">Made by</span>
              <span className="text-xs font-black bg-clip-text text-transparent bg-gradient-to-r from-sky-400 via-indigo-300 to-violet-400 select-none tracking-wide">
                Manue23aa
              </span>
            </div>

            <div className="h-4 w-[1px] bg-white/10" />

            {/* Smooth Soundwave Indicator representing active audio sync */}
            <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[10px] font-mono leading-none rounded-xl">
              <div className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500" />
              </div>
              <span className="uppercase tracking-wider select-none font-bold hidden sm:inline">Audio synced</span>
              
              {/* Dynamic visual micro soundwaves */}
              <div className="flex items-end gap-0.5 h-2 w-3 ml-0.5 select-none animate-pulse">
                <div className="w-[1.5px] bg-emerald-400 rounded-full animate-bounce h-1" style={{ animationDelay: '0.1s', animationDuration: '0.6s' }} />
                <div className="w-[1.5px] bg-emerald-400 rounded-full animate-bounce h-2" style={{ animationDelay: '0.3s', animationDuration: '0.5s' }} />
                <div className="w-[1.5px] bg-emerald-400 rounded-full animate-bounce h-1.5" style={{ animationDelay: '0.5s', animationDuration: '0.7s' }} />
              </div>
            </div>

            <div className="h-4 w-[1px] bg-white/10" />

            {/* Leftmost connected mini light pulse marker */}
            <div 
              className="flex items-center gap-1.5 px-1 py-1 text-[10px] text-slate-400 font-mono"
              title={status}
            >
              <div className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isConnected ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                <span className={`relative inline-flex rounded-full h-2 w-2 ${isConnected ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              </div>
              <span className="hidden md:inline select-none truncate max-w-[80px]" title={status}>
                {isConnected ? 'LIVE' : 'SYNCING'}
              </span>
            </div>

            <div className="h-4 w-[1px] bg-white/10" />

            {/* Scale View Mode Toggler */}
            <button
              type="button"
              onClick={() => setScaleViewport(!scaleViewport)}
              className={`h-9 w-9 flex items-center justify-center rounded-xl cursor-pointer transition-all duration-200 ${
                scaleViewport 
                  ? 'bg-white/5 border border-white/10 text-slate-300 hover:bg-white/15' 
                  : 'bg-amber-500/15 border border-amber-500/35 text-amber-300 text-shadow'
              }`}
              title={scaleViewport ? "Enable FHD Native Resolution (1:1)" : "Fit screen to viewport aspect ratio"}
            >
              {scaleViewport ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Browser Fullscreen toggle button */}
            <button
              type="button"
              onClick={toggleFullscreen}
              className={`h-9 w-9 flex items-center justify-center rounded-xl cursor-pointer transition-all duration-200 bg-white/5 border border-white/10 text-slate-300 hover:bg-white/15`}
              title={isFullscreen ? "Exit Fullscreen Desktop" : "Enter High-Immersive Fullscreen"}
            >
              {isFullscreen ? (
                <Minimize className="w-4 h-4 text-blue-400" />
              ) : (
                <Maximize className="w-4 h-4 text-blue-400" />
              )}
            </button>

            {/* Quick Reboot VNC Session */}
            <button
              type="button"
              onClick={handleRestartDesktop}
              disabled={isRestarting}
              className={`h-9 w-9 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:bg-white/15 cursor-pointer disabled:opacity-40 transition-all duration-200 ${isRestarting ? 'animate-pulse' : ''}`}
              title="Soft Reboot stuck workspace applications"
            >
              <RefreshCw className={`w-4 h-4 ${isRestarting ? 'animate-spin' : ''}`} />
            </button>

            {/* Interactive User Info Manual Trigger */}
            <button
              type="button"
              onClick={() => setShowInfo(true)}
              className="h-9 w-9 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:bg-white/15 cursor-pointer transition-all duration-200"
              title="Open Desktop Guide"
            >
              <HelpCircle className="w-4 h-4 text-sky-400" />
            </button>

            <div className="h-4 w-[1px] bg-white/10" />

            {/* Collapse Controls Switch Button */}
            <button
              type="button"
              onClick={() => setControlsCollapsed(true)}
              className="h-9 w-6 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer rounded-lg hover:bg-white/5"
              title="Fold panel to edge"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

          </div>
        )}
      </div>

      {/* Floating Glass user guide dialog backdrop and overlay */}
      {showInfo && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900/95 border border-slate-700/60 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-100 flex flex-col gap-4 relative animate-fade-in">
            <button 
              type="button"
              onClick={() => setShowInfo(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition cursor-pointer p-1 rounded-full hover:bg-slate-800"
              title="Close guide"
            >
              <span className="text-xl">×</span>
            </button>
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <Info className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-base">Cloud Desktop User Guide</h3>
            </div>
            <div className="space-y-3.5 my-1 text-xs leading-relaxed max-h-[50vh] overflow-y-auto pr-1">
              <p>
                <strong>🖥️ True Full Screen:</strong> Trigger standard, device-independent fullscreen monitor mode directly with the <strong>Fullscreen</strong> control in the floating glass panel.
              </p>
              <p>
                <strong>🔊 Liquid Glass Audio:</strong> Enabling dynamic sound opens real-time pipeline audio straight from the backend with zero browser drift.
              </p>
              <p>
                <strong>⚙️ Sizing Resolution:</strong> Swap between <strong>Fit Viewport</strong> (rescales content perfectly) and <strong>UHD Sharp 1:1</strong> (locks ultra-sharp canvas rendering).
              </p>
              <p>
                <strong>🔄 Refresh Session:</strong> Stuck menus or connection hiccups can be instantly resolved by clicking the <strong>Refresh Desktop</strong> icon.
              </p>
              <p>
                <strong>📂 Local persistence:</strong> Chromium cookiefiles, configuration settings, and downloaded files persist safely between restarts.
              </p>
            </div>
            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button 
                type="button"
                onClick={() => setShowInfo(false)}
                className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 font-medium text-xs transition cursor-pointer text-white shadow-md shadow-blue-900/20"
              >
                Got it, let's go!
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
